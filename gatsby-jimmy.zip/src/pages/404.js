import React from "react"

const error404 = () => {
  return <div>404</div>
}

export default error404
